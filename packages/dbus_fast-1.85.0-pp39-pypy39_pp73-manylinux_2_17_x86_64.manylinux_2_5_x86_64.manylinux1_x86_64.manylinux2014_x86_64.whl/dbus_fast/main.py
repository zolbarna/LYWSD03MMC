def add(n1: int, n2: int) -> int:
    return n1 + n2
